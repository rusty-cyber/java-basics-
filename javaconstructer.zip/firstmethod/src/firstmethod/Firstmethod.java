
package firstmethod;


public class Firstmethod {

    
    public static void main(String[] args) {
       
        System.out.println("Advantages of methods.");
        
        displayLine();
        System.out.println("Write once use many times");
        displayLine();
    }
    
    public satatic void displayLine()
    {
        for (int i = 1; i <= 40; i++)
        {
            System.out.println("_");
           
        }
        System.out.println(" ");
    }
    
}
