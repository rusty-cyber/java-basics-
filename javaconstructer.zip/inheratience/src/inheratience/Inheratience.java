
package inheratience;


public class Inheratience {

    
    public static void main(String[] args) {
   
}
    }
    

