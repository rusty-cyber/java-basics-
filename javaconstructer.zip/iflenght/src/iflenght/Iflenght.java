
package iflenght;
  import java.util.Scanner;

public class Iflenght {
   

    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
     int length;
     int breath;
     
     System.out.println("enter length");
     length=keyboard.nextInt();
     
     System.out.println("enter breath");
     breath=keyboard.nextInt();
     
     if (length == breath  )
      System.out.println("this is a square");
     
    }
     
    else { System.out.println();
     
     
     
            
             
             
        
        
        
        
                
              
        
      
    }
    
}
