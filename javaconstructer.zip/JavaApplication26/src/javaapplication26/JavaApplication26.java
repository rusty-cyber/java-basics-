
package javaapplication26;


public class JavaApplication26 {

    
    public static void main(String[] args) {
              
        int[] aryNums;
        
        aryNums = new int[6];
        
        aryNums[0] = 10;
        aryNums[1] = 14;
        aryNums[2] = 36;
        aryNums[3] = 27;
        aryNums[4] = 43;
        aryNums[5] = 18;
        
        System.out.println( aryNums[4]);
    }
    
}
