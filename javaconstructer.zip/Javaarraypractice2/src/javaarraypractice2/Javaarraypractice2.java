
package javaarraypractice2;


public class Javaarraypractice2 {

    
    public static void main(String[] args) {
        String[] aryString = new String[6];
        
        aryString[0]= "Sunday";
        aryString[1]= "monday";
        aryString[2]= "tuesday";
        aryString[3]= "wensday";
        aryString[4]="thurday";
        aryString[5]="friday";
        aryString[6]="saturday";
        
        Arrays.sort(aryString);
         
        int i;
        for (i=0; i )
    }
    
}
