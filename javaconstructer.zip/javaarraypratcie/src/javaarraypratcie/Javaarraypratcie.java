
package javaarraypratcie;


public class Javaarraypratcie {

    
    public static void main(String[] args) {
       int[] numArray;
       
       numArray = new int [14];
       
         numArray[0] = 1;
         numArray[1] = 2;
         numArray[2] = 3;
         numArray[3] = 4;
         numArray[4] = 5;
         numArray[5] = 6;
         numArray[6] = 7;
         numArray[7] = 8;
         numArray[8] = 9;
         numArray[9] = 10;
         numArray[10] = 11;
         numArray[11] = 12;
         numArray[12] = 13;
         numArray[13] = 14;
         numArray[14] = 15;
         
          System.out.println( numArray[9] );
         
    }
    
}
