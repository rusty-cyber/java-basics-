
package java.practice;
import java.util.Scanner;
public class JavaPractice {

    
    public static void main(String[] args) {
      
    }
    
}
