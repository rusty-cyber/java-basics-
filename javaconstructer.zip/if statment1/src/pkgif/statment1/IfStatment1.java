
package pkgif.statment1;


public class IfStatment1 {

    public static void main(String[] args) {
        int user = 17;
        
        if (user <= 18) {
        System.out.println("user is 18 or younger");
            
        }
        else {
          System.out.println("user is older than 18");
        }
  
    }
    
}
